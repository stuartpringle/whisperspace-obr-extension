import skillsJson from "./generated/skills.json";
import type { SkillsData } from "./types";

export const skillsData = skillsJson as SkillsData;
