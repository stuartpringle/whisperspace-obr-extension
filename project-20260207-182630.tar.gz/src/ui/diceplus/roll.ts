import OBR from "@owlbear-rodeo/sdk";

export const DICEPLUS_CHANNEL_READY = "dice-plus/isReady";
export const DICEPLUS_CHANNEL_ROLL_REQUEST = "dice-plus/roll-request";

/**
 * IMPORTANT:
 * Dice+ returns results on `${source}/roll-result`
 * This MUST be a stable string used consistently for send + listen.
 */
export const DICEPLUS_SOURCE = "whisperspace.obr.sheet";

export type RollTarget = "everyone" | "self" | "dm" | "gm_only";

export async function checkDicePlusReady(timeoutMs = 1000): Promise<boolean> {
  const requestId = crypto.randomUUID();

  return new Promise<boolean>((resolve) => {
    const unsubscribe = OBR.broadcast.onMessage(
      DICEPLUS_CHANNEL_READY,
      (event) => {
        const data = event.data as any;
        if (data?.requestId === requestId && data.ready === true) {
          unsubscribe();
          resolve(true);
        }
      }
    );

    void OBR.broadcast.sendMessage(
      DICEPLUS_CHANNEL_READY,
      { requestId, timestamp: Date.now() },
      { destination: "ALL" }
    );

    setTimeout(() => {
      unsubscribe();
      resolve(false);
    }, timeoutMs);
  });
}

export function buildWhisperspaceSkillNotation(opts: {
  netDice: number;      // -2..+2
  modifier: number;     // flat modifier
  label: string;        // roll label
}) {
  const net = Math.max(-2, Math.min(2, Math.trunc(opts.netDice)));
  const diceCount = 1 + Math.abs(net);

  let base = "1d12";
  if (net > 0) base = `${diceCount}d12kh1`;
  if (net < 0) base = `${diceCount}d12kl1`;

  const mod = Number.isFinite(opts.modifier) ? Math.trunc(opts.modifier) : 0;
  const modSuffix =
    mod === 0 ? "" : mod > 0 ? ` +${mod}` : ` ${mod}`;

  return `${base} # ${opts.label}${modSuffix}`;
}

/**
 * Fire-and-forget roll (skills, attacks, etc.)
 */
export async function rollWithDicePlus(opts: {
  diceNotation: string;
  rollTarget?: RollTarget;
  showResults?: boolean;
}) {
  const rollId = crypto.randomUUID();

  await OBR.broadcast.sendMessage(
    DICEPLUS_CHANNEL_ROLL_REQUEST,
    {
      rollId,
      playerId: await OBR.player.getId(),
      playerName: await OBR.player.getName(),
      rollTarget: opts.rollTarget ?? "everyone",
      diceNotation: opts.diceNotation,
      showResults: opts.showResults ?? true,
      timestamp: Date.now(),
      source: DICEPLUS_SOURCE,
    },
    { destination: "ALL" }
  );

  return rollId;
}

/**
 * Roll and wait for a numeric total (initiative)
 */
export async function rollWithDicePlusTotal(opts: {
  diceNotation: string;
  rollTarget?: RollTarget;
  showResults?: boolean;
  timeoutMs?: number;
}): Promise<number> {
  const ready = await checkDicePlusReady();
  if (!ready) {
    throw new Error("Dice+ is not available");
  }

  const rollId = crypto.randomUUID();
  const timeoutMs = opts.timeoutMs ?? 5000;

  return new Promise<number>(async (resolve, reject) => {
    const unsubscribeResult = OBR.broadcast.onMessage(
      `${DICEPLUS_SOURCE}/roll-result`,
      (event) => {
        const data = event.data as any;
        if (data?.rollId === rollId) {
          cleanup();
          resolve(Number(data?.result?.totalValue ?? 0));
        }
      }
    );

    const unsubscribeError = OBR.broadcast.onMessage(
      `${DICEPLUS_SOURCE}/roll-error`,
      (event) => {
        const data = event.data as any;
        if (data?.rollId === rollId) {
          cleanup();
          reject(new Error(data?.error || "Dice+ roll failed"));
        }
      }
    );

    const cleanup = () => {
      unsubscribeResult();
      unsubscribeError();
    };

    await OBR.broadcast.sendMessage(
      DICEPLUS_CHANNEL_ROLL_REQUEST,
      {
        rollId,
        playerId: await OBR.player.getId(),
        playerName: await OBR.player.getName(),
        rollTarget: opts.rollTarget ?? "everyone",
        diceNotation: opts.diceNotation,
        showResults: opts.showResults ?? true,
        timestamp: Date.now(),
        source: DICEPLUS_SOURCE,
      },
      { destination: "ALL" }
    );

    setTimeout(() => {
      cleanup();
      reject(new Error("Dice+ roll timed out (no roll-result received)"));
    }, timeoutMs);
  });
}
